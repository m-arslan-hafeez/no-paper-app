import 'package:flutter/material.dart';

import 'application.dart';

void main() {
  runApp(Application());
}
